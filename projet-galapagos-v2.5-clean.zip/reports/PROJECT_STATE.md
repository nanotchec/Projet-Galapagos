# Etat Projet V2.4.8 + candidat V2.5

- Derniere version validee : V2.4.8.
- Verdict valide : Finalisation robuste du validateur de resampling via focused Unit/Integration split sous les 5 secondes.
- Version candidate : V2.5.
- Statut candidate : pending_external_audit.
- Direction suivante : Construction de la première couche de features OHLCV causales physiques, strictes et auditables (Causal OHLCV Feature Store Preview).
- V2.5 produit uniquement des features OHLCV causales déterministes sur BTCUSDT 2024-01-15 à partir des données V2.4 validées, sous forme de fichiers Parquet Gold sous `data/gold/features/`.
- La version candidate V2.5 a été finalisée avec succès :
  - L'architecture modulaire de features sous `src/galapagos/features/` (`causal_ohlcv.py`, `quality.py`, `validation.py`, `schemas.py`, `registry.py`) est 100% implémentée et validée.
  - Le calcul des features causales intègre un warmup physique obligatoire de 30 lignes et des protections contre les divisions par zéro, empêchant strictement toute forme de triche ou de fuite temporelle (lookahead).
  - La validation V2.5 (`validate_causal_feature_store_v2_5.py`) intègre de manière récursive la validation complète des étapes V2.3 et V2.4.
  - Toutes les colonnes extra, futures (comme future_return), les labels (comme strategy_validated) ou termes interdits sont physiquement scannés et rejetés par le validateur V2.5.
  - La synchronisation physique du manifest (`causal_feature_store_v2_5_manifest.json`), du rapport qualité JSON et du rapport de sécurité Markdown est pleinement opérationnelle et validée.
  - L'audit et le smoke test de structure du package zip épuré `projet-galapagos-v2.5-clean.zip` passent à 100% dans un environnement temporaire isolé.
- Aucun trading réel, paper live, ordre, ML, label ou backtest n'est autorisé.
