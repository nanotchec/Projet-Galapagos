# Latest Metrics V2.3.1 + candidat V2.4.6

- Derniere version validee : V2.3.1.
- Version candidate : V2.4.6.
- Statut : pending_external_audit.
- Raw public archive BTCUSDT 1m 2024-01-15 : cree.
- Silver OHLCV Parquet : cree, sans colonne `normalized_file_sha256`.
- Sorties V2.4 attendues : 5m = 288 lignes, 15m = 96 lignes, 1h = 24 lignes.
- V2.4.6 importe dynamiquement le schema canonique `OHLCV_COLUMNS` depuis `schemas.py` dans son smoke test de ZIP clean, et maintient le rejet strict de toute colonne additionnelle ou desordre physique sur 1m/5m/15m/1h.
- Le fichier complet `tests/validation/test_ohlcv_resampling_v2_4_validator.py` s'execute de maniere ultra-robuste sous les 12 secondes grace a la fixture optimized de copie de template a plat.
- V2.4.6 reste data-only, sans cle API, sans endpoint prive, sans trading, sans paper live, sans ordre, sans ML, sans labels et sans backtest.
