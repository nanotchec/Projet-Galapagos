# Latest Metrics V2.3.1 + candidat V2.4.5

- Derniere version validee : V2.3.1.
- Version candidate : V2.4.5.
- Statut : pending_external_audit.
- Raw public archive BTCUSDT 1m 2024-01-15 : cree.
- Silver OHLCV Parquet : cree, sans colonne `normalized_file_sha256`.
- Sorties V2.4 attendues : 5m = 288 lignes, 15m = 96 lignes, 1h = 24 lignes.
- V2.4.5 impose un controle physique strict (`list(frame.columns) == OHLCV_COLUMNS`) sur tous les Parquet silver 1m, 5m, 15m et 1h, interdisant toute colonne additionnelle ou desordre physique.
- Le fichier complet `tests/validation/test_ohlcv_resampling_v2_4_validator.py` s'execute desormais en moins de 11 secondes grace a la fixture optimized `valid_v2_4_project`.
- V2.4.5 reste data-only, sans cle API, sans endpoint prive, sans trading, sans paper live, sans ordre, sans ML, sans labels et sans backtest.
