"""Paper execution components."""

