"""Evaluation harness utilities."""

