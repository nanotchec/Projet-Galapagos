"""Indicator computation modules."""

