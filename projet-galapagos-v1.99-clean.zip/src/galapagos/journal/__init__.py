"""Journal and persistence components."""

